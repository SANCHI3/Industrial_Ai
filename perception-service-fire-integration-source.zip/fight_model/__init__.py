"""Trainable pose-sequence fight classifier."""

__all__ = ["model", "dataset", "infer"]
