"""
Assembles a full incident report dict matching the schema in the design
doc (section 10) and appends it to a local JSON-lines file. This stands
in for "POST /api/incidents" to the Spring Boot backend until that
service exists -- swap `save()` for an HTTP call later without touching
the rest of the pipeline.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

from reporting.description_generator import generate_description, recommended_action


class IncidentReporter:
    def __init__(self, output_path: str, camera_locations: dict):
        self.output_path = output_path
        self.camera_locations = camera_locations
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    def build_and_save(
        self,
        confirmed_event,
        severity: str,
        clip_before: Optional[str] = None,
        keyframes: Optional[list] = None,
    ) -> dict:
        location = self.camera_locations.get(confirmed_event.camera_id, confirmed_event.camera_id)
        detail = dict(confirmed_event.candidate.detail)

        report = {
            "incident_id": f"INC-{datetime.now(timezone.utc):%Y%m%d}-{uuid.uuid4().hex[:6].upper()}",
            "camera_id": confirmed_event.camera_id,
            "location": location,
            "event_type": confirmed_event.event_type,
            "confidence_tier": confirmed_event.tier,
            "confidence_score": round(confirmed_event.confidence, 2),
            "severity": severity,
            "detected_at": datetime.now(timezone.utc).isoformat(),
            "duration_s": confirmed_event.duration_s,
            "description": generate_description(confirmed_event.event_type, location, detail),
            "detected_objects": [
                {"track_id": tid, "role": "primary" if i == 0 else "secondary"}
                for i, tid in enumerate(confirmed_event.candidate.track_ids)
            ],
            "zone_id": confirmed_event.candidate.zone_id,
            "detail": detail,
            "evidence": {
                "clip_before": clip_before,
                "clip_after": None,   # filled in later via update_evidence() once the post-capture window completes
                "keyframes": keyframes or [],
            },
            "recommended_action": recommended_action(confirmed_event.event_type),
            "review_status": "pending",
        }
        self.save(report)
        return report

    def save(self, report: dict):
        with open(self.output_path, "a") as f:
            f.write(json.dumps(report) + "\n")

    def update_evidence(self, incident_id: str, updates: dict):
        """
        JSON-lines files aren't updatable in place, so this appends a small
        "evidence update" record instead of rewriting incidents.jsonl. This
        stands in for what would be a `PATCH /api/incidents/{id}/evidence`
        call to the real backend once it exists -- the important part is
        the calling code in main.py only needs to change its transport,
        not its logic, when that backend is wired up.
        """
        update_path = os.path.join(os.path.dirname(self.output_path) or ".", "evidence_updates.jsonl")
        record = {"incident_id": incident_id, "updated_at": datetime.now(timezone.utc).isoformat(), **updates}
        with open(update_path, "a") as f:
            f.write(json.dumps(record) + "\n")
