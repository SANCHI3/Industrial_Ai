"""
Rule-based event candidate generation, evaluated every processing cycle
against the current TemporalBuffer for a camera. This is the cheap, fast
path described in the design doc -- pure geometry/kinematics on top of
YOLO + ByteTrack, no extra model inference.

Each rule returns zero or more EventCandidate objects. Candidates are NOT
incidents yet -- they still have to pass through event confirmation
(confirmation/event_confirmation.py) before becoming Confirmed/Probable.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from temporal.geometry import point_in_polygon
from temporal.temporal_buffer import TemporalBuffer, TrackHistory


@dataclass
class EventCandidate:
    event_type: str
    track_ids: List[int]
    camera_id: str
    zone_id: Optional[str] = None
    detail: Dict[str, Any] = field(default_factory=dict)
    raw_confidence: float = 0.6  # rule-based signals get a fixed/derived confidence, not a learned score


class RuleEngine:
    def __init__(self, camera_config: dict, thresholds: dict):
        self.camera_id = camera_config["id"]
        self.zones = camera_config.get("zones", [])
        self.rules_cfg = thresholds["rules"]

    def evaluate(self, buffer: TemporalBuffer) -> List[EventCandidate]:
        candidates: List[EventCandidate] = []
        candidates += self._check_intrusion(buffer)
        candidates += self._check_loitering(buffer)
        candidates += self._check_crowd(buffer)
        candidates += self._check_fall(buffer)
        return candidates

    # ---- Intrusion -----------------------------------------------------
    def _check_intrusion(self, buffer: TemporalBuffer) -> List[EventCandidate]:
        out = []
        restricted_zones = [z for z in self.zones if z["type"] == "restricted"]
        if not restricted_zones:
            return out

        min_frames = self.rules_cfg["intrusion"]["min_frames_inside"]

        for person in buffer.tracks_by_class("person"):
            for zone in restricted_zones:
                foot = person.states[-1].foot_point
                inside_now = point_in_polygon(foot, zone["polygon"])
                if not inside_now:
                    person.zone_entry_times.pop(zone["zone_id"], None)
                    continue

                if zone["zone_id"] not in person.zone_entry_times:
                    person.zone_entry_times[zone["zone_id"]] = time.time()

                # count how many of the last few states were also inside -- filters
                # single-frame detection flicker right at the zone boundary
                recent = list(person.states)[-min_frames:]
                inside_count = sum(1 for s in recent if point_in_polygon(s.foot_point, zone["polygon"]))
                if inside_count >= min_frames:
                    out.append(EventCandidate(
                        event_type="intrusion",
                        track_ids=[person.track_id],
                        camera_id=self.camera_id,
                        zone_id=zone["zone_id"],
                        detail={"zone_type": zone["type"]},
                        raw_confidence=0.85,
                    ))
        return out

    # ---- Loitering -------------------------------------------------------
    def _check_loitering(self, buffer: TemporalBuffer) -> List[EventCandidate]:
        out = []
        dwell_threshold = self.rules_cfg["loitering"]["dwell_seconds"]
        now = time.time()

        for person in buffer.tracks_by_class("person"):
            for zone_id, entry_time in person.zone_entry_times.items():
                dwell = now - entry_time
                if dwell >= dwell_threshold:
                    out.append(EventCandidate(
                        event_type="loitering",
                        track_ids=[person.track_id],
                        camera_id=self.camera_id,
                        zone_id=zone_id,
                        detail={"dwell_seconds": round(dwell, 1)},
                        raw_confidence=min(0.5 + dwell / (dwell_threshold * 4), 0.95),
                    ))
        return out

    # ---- Crowd gathering ---------------------------------------------
    def _check_crowd(self, buffer: TemporalBuffer) -> List[EventCandidate]:
        out = []
        threshold = self.rules_cfg["crowd"]["person_count_threshold"]
        persons = buffer.tracks_by_class("person")
        count = len(persons)
        if count >= threshold:
            out.append(EventCandidate(
                event_type="crowd",
                track_ids=[p.track_id for p in persons],
                camera_id=self.camera_id,
                detail={"count": count, "threshold": threshold},
                raw_confidence=min(0.5 + (count - threshold) * 0.1, 0.95),
            ))
        return out

    # ---- Fall (aspect-ratio flip + stillness heuristic) ------------------
    def _check_fall(self, buffer: TemporalBuffer) -> List[EventCandidate]:
        """
        A fall candidate requires two things, evaluated separately so the
        "was standing then flipped" check and the "has stayed down" check
        don't fight over the same time window:
          1. A transition: a standing (tall, ar<0.8) state shortly followed
             by a fallen (wide, ar>1.2) state, within `flip_window` seconds.
          2. Persistence: the person has remained in that fallen pose,
             roughly stationary, for at least `stillness_seconds` since the
             transition -- NOT measured against the whole rolling buffer
             (which would still contain the pre-fall standing states and
             could never satisfy "stillness").
        """
        out = []
        cfg = self.rules_cfg["fall"]
        flip_window = cfg["aspect_ratio_flip_seconds"]
        stillness_needed = cfg["stillness_seconds"]

        for person in buffer.tracks_by_class("person"):
            states = list(person.states)
            if len(states) < 2:
                continue

            last = states[-1]
            if last.aspect_ratio <= 1.2:
                continue  # not currently in a "fallen" pose

            # walk backwards to find the contiguous run of "fallen" states
            fallen_run = []
            for s in reversed(states):
                if s.aspect_ratio > 1.2:
                    fallen_run.append(s)
                else:
                    break
            fallen_run.reverse()
            onset = fallen_run[0]

            # require a standing state shortly before the fall onset -- this
            # is what distinguishes "just fell" from "has been lying/sitting
            # there the whole time" (e.g. a bench, not an incident)
            pre_onset = [s for s in states if onset.timestamp - flip_window <= s.timestamp < onset.timestamp]
            was_standing_before = any(s.aspect_ratio < 0.8 for s in pre_onset)
            if not was_standing_before:
                continue

            duration_fallen = last.timestamp - onset.timestamp
            xs = [s.center[0] for s in fallen_run]
            ys = [s.center[1] for s in fallen_run]
            stayed_put = (max(xs) - min(xs) <= 8.0) and (max(ys) - min(ys) <= 8.0)

            if stayed_put and duration_fallen >= stillness_needed:
                out.append(EventCandidate(
                    event_type="fall",
                    track_ids=[person.track_id],
                    camera_id=self.camera_id,
                    detail={
                        "aspect_ratio_before": round(pre_onset[-1].aspect_ratio, 2) if pre_onset else None,
                        "aspect_ratio_after": round(last.aspect_ratio, 2),
                        "still_seconds": round(duration_fallen, 1),
                    },
                    raw_confidence=0.7,
                ))
        return out
