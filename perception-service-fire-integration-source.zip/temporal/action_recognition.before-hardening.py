"""
Fight/violence detection (design doc section 3/4: the one event type where
rules genuinely aren't enough and real temporal/pose learning earns its
cost). Runs in two possible modes:

  "heuristic" (default, no training data required): scores a short pose
  sequence using hand-crafted jerkiness + proximity signals. This is
  explicitly a rough proxy, not a trained classifier -- expect a real
  false-positive/false-negative rate, and treat its output the same way
  the design doc treats all fight-detection output: capped confidence,
  always requires persistence before CONFIRMED, human review recommended.

  "model": loads a trained PoseSequenceLSTM checkpoint (see
  training/train_fight_lstm.py) and scores the same pose sequence with a
  learned classifier instead of the heuristic. This is the intended
  end-state, but requires you to actually collect/label data and train it
  (design doc section 15-16) -- there is no pretrained checkpoint shipped
  here, because none of the available public "fight" datasets are close
  enough to arbitrary CCTV footage to be trustworthy without fine-tuning
  on footage from your own camera.

Only invoked when temporal.motion_gate.MotionOfInterestGate finds a
candidate pair this cycle -- see the "expensive, gated path" in the
design doc's real-time performance section.
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Tuple

import numpy as np

from detection.pose_estimator import PoseEstimator
from temporal.fight_features import FEATURE_DIM, match_pose_to_bbox, pair_feature_vector
from temporal.motion_gate import MotionOfInterestGate
from temporal.rule_engine import EventCandidate
from temporal.temporal_buffer import TemporalBuffer


@dataclass
class PairSequence:
    frames: Deque[np.ndarray] = field(default_factory=lambda: deque(maxlen=32))
    last_updated: float = field(default_factory=time.time)


class FightDetector:
    def __init__(self, camera_id: str, cfg: dict):
        self.camera_id = camera_id
        self.enabled = cfg.get("enabled", True)
        self.mode = cfg.get("mode", "heuristic")
        self.window_frames = cfg.get("window_frames", 10)
        self.min_frames_for_eval = cfg.get("min_frames_for_eval", 5)
        self.confidence_threshold = cfg.get("confidence_threshold", 0.6)
        self.pair_stale_after_s = cfg.get("pair_stale_after_s", 5.0)

        self.gate = MotionOfInterestGate(
            proximity_px=cfg["gate"]["proximity_px"],
            velocity_threshold_px_s=cfg["gate"]["velocity_threshold_px_s"],
        )

        self._pose_estimator: Optional[PoseEstimator] = None  # lazy-loaded, only if the gate ever fires
        self._pose_model_path = cfg.get("pose_model_path", "yolov8n-pose.pt")
        self._pair_sequences: Dict[Tuple[int, int], PairSequence] = {}

        self._model = None
        self._use_checkpoint_threshold = cfg.get("use_checkpoint_threshold", True)
        if self.mode == "model":
            checkpoint = cfg.get("model_checkpoint")
            if checkpoint:
                self._model = self._load_model(checkpoint)
                self.window_frames = self._model.max_frames
                if self._use_checkpoint_threshold:
                    self.confidence_threshold = self._model.threshold
            else:
                print(f"[{camera_id}] fight_detection.mode='model' but no model_checkpoint configured "
                      f"-- falling back to 'heuristic' mode")
                self.mode = "heuristic"

    def _load_model(self, checkpoint_path: str):
        # Local import keeps torch optional while heuristic mode is active.
        # This loader understands the metadata-rich checkpoint created by
        # fight_model/train.py (architecture, feature size and threshold).
        from fight_model.infer import FightSequenceClassifier
        model = FightSequenceClassifier(checkpoint_path)
        if model.input_dim != FEATURE_DIM:
            raise ValueError(
                f"fight checkpoint expects {model.input_dim} features, "
                f"but pair_feature_vector produces {FEATURE_DIM}"
            )
        return model

    def _get_pose_estimator(self) -> PoseEstimator:
        if self._pose_estimator is None:
            self._pose_estimator = PoseEstimator(model_path=self._pose_model_path)
        return self._pose_estimator

    def evaluate(self, buffer: TemporalBuffer, frame: np.ndarray) -> List[EventCandidate]:
        if not self.enabled:
            return []

        candidate_pairs = self.gate.find_candidate_pairs(buffer)
        self._evict_stale_pairs()

        if not candidate_pairs:
            return []

        # Training extraction selects one most plausible interacting pair per
        # frame. Scoring every pair in a crowd creates a train/runtime mismatch
        # and a combinatorial false-positive explosion. Keep only the closest
        # pair after normalizing distance by body height.
        candidate_pairs = self._select_best_candidate_pair(buffer, candidate_pairs)

        poses = self._get_pose_estimator().estimate(frame)
        if not poses:
            return []

        out: List[EventCandidate] = []
        for track_id_a, track_id_b in candidate_pairs:
            hist_a, hist_b = buffer.get(track_id_a), buffer.get(track_id_b)
            if hist_a is None or hist_b is None or not hist_a.states or not hist_b.states:
                continue

            pose_a = match_pose_to_bbox(poses, hist_a.states[-1].bbox)
            pose_b = match_pose_to_bbox(poses, hist_b.states[-1].bbox)
            if pose_a is None or pose_b is None or pose_a is pose_b:
                continue

            feature = pair_feature_vector(pose_a, pose_b)
            speed = self._pair_speed(hist_a, hist_b)
            feature[-1] = speed

            key = tuple(sorted((track_id_a, track_id_b)))
            seq = self._pair_sequences.setdefault(key, PairSequence(frames=deque(maxlen=self.window_frames)))
            seq.frames.append(feature)
            seq.last_updated = time.time()

            if len(seq.frames) < self.min_frames_for_eval:
                continue

            sequence_array = np.stack(list(seq.frames))
            score = self._score_sequence(sequence_array)

            if score >= self.confidence_threshold:
                out.append(EventCandidate(
                    event_type="fight",
                    track_ids=[track_id_a, track_id_b],
                    camera_id=self.camera_id,
                    detail={
                        "mode": self.mode,
                        "score": round(float(score), 2),
                        "frames_evaluated": len(seq.frames),
                    },
                    raw_confidence=float(score),
                ))
        return out

    def _select_best_candidate_pair(self, buffer: TemporalBuffer, candidate_pairs):
        def normalized_distance(pair):
            hist_a, hist_b = buffer.get(pair[0]), buffer.get(pair[1])
            if hist_a is None or hist_b is None or not hist_a.states or not hist_b.states:
                return float("inf")
            state_a, state_b = hist_a.states[-1], hist_b.states[-1]
            distance = float(np.hypot(
                state_a.center[0] - state_b.center[0],
                state_a.center[1] - state_b.center[1],
            ))
            mean_height = max((state_a.height + state_b.height) / 2.0, 1.0)
            pair_key = tuple(sorted(pair))
            existing_frames = len(self._pair_sequences[pair_key].frames) if pair_key in self._pair_sequences else 0
            continuity_bonus = min(existing_frames, 10) * 0.05
            return distance / mean_height - continuity_bonus

        best = min(candidate_pairs, key=normalized_distance)
        return [best]

    def _pair_speed(self, hist_a, hist_b) -> float:
        va, vb = hist_a.velocity(), hist_b.velocity()
        speed = 0.0
        if va:
            speed += float(np.hypot(*va))
        if vb:
            speed += float(np.hypot(*vb))
        return speed

    def _score_sequence(self, sequence: np.ndarray) -> float:
        if self.mode == "model" and self._model is not None:
            return self._score_with_model(sequence)
        return self._score_heuristic(sequence)

    def _score_with_model(self, sequence: np.ndarray) -> float:
        return self._model.score(sequence)

    def _score_heuristic(self, sequence: np.ndarray) -> float:
        """
        Hand-crafted proxy: fight-like motion tends to be (a) high-magnitude
        frame-to-frame keypoint displacement and (b) jerky/oscillating
        rather than smooth, combined with (c) sustained close proximity.
        This is NOT a substitute for a trained classifier -- see module
        docstring. Tune the scaling constants below against your own
        recorded footage (staged fights vs. staged running/playing/hugging)
        before relying on this for a demo.
        """
        kp_dim = (FEATURE_DIM - 2)  # both people's normalized keypoints
        kp_part = sequence[:, :kp_dim]
        diffs = np.diff(kp_part, axis=0)
        if len(diffs) == 0:
            return 0.0
        frame_motion = np.linalg.norm(diffs, axis=1)

        mean_motion = float(np.mean(frame_motion))
        motion_jerkiness = float(np.std(np.diff(frame_motion))) if len(frame_motion) > 1 else 0.0

        avg_distance = float(np.mean(sequence[:, -2]))
        proximity_score = max(0.0, 1.0 - avg_distance / 200.0)

        motion_score = min(mean_motion * 6.0 + motion_jerkiness * 12.0, 1.0)
        score = 0.65 * motion_score + 0.35 * proximity_score
        return float(np.clip(score, 0.0, 1.0))

    def _evict_stale_pairs(self):
        now = time.time()
        stale = [k for k, s in self._pair_sequences.items() if now - s.last_updated > self.pair_stale_after_s]
        for k in stale:
            del self._pair_sequences[k]
