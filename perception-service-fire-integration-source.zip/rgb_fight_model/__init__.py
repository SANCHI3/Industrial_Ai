"""RGB temporal fight classifier based on torchvision R3D-18."""
